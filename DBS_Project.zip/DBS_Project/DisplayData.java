package DBS_Project;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class DisplayData implements ActionListener {

    JFrame f;
    JLabel id8,id,aid,id1,aid1,id2,aid2,id3,aid3,id4,aid4,id5,aid5,id6,
            aid6,id7,aid7, id9,id10,id11,id12,id13,id14,id15,id16,id17,lab;
    String Name,Rollno,F_name,Phone_no,Address,Age,DOB,CNIC;
    JButton b1,b2;
    ImageIcon icon;
    DisplayData(String e_id) {
        try {
            DBConnection conn = new DBConnection();
            String str = "select * from student where Rollno = '" + e_id + "'";
            ResultSet rs = conn.stmt.executeQuery(str);
            while (rs.next()) {


                Name = rs.getString("Name");
                Rollno = rs.getString("Rollno");
                F_name = rs.getString("F_name");
                Phone_no = rs.getString("Phone_no");
                Address = rs.getString("Address");
                Age = rs.getString("Age");
                DOB = rs.getString("DOB");
                CNIC = rs.getString("CNIC");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        f = new JFrame("Display Data");
        f.setVisible(true);
        f.setSize(595, 642);
        f.setLocation(450, 200);
        f.setBackground(Color.black);
        f.setLayout(null);


        id9 = new JLabel();
        id9.setBounds(0, 0, 595, 642);
        id9.setLayout(null);
        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("Icons/print.jpg"));
        id9.setIcon(img);

        id8 = new JLabel("Student Details");
        id8.setBounds(50, 10, 250, 30);
        f.add(id8);
        id8.setFont(new Font("serif", Font.BOLD, 25));
        id9.add(id8);
        f.add(id9);


        id1 = new JLabel("Name:");
        id1.setBounds(50, 120, 100, 30);
        id1.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(id1);

        aid1 = new JLabel(Name);
        aid1.setBounds(200, 120, 300, 30);
        aid1.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(aid1);


        id = new JLabel("Roll no:");
        id.setBounds(50, 70, 120, 30);
        id.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(id);

        aid = new JLabel(Rollno);
        aid.setBounds(200, 70, 200, 30);
        aid.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(aid);

        id2 = new JLabel("Father's Name:");
        id2.setBounds(50, 170, 200, 30);
        id2.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(id2);

        aid2 = new JLabel(F_name);
        aid2.setBounds(200, 170, 300, 30);
        aid2.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(aid2);

        id4 = new JLabel("Phone No:");
        id4.setBounds(50, 270, 100, 30);
        id4.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(id4);

        aid4 = new JLabel(Phone_no);
        aid4.setBounds(200, 270, 300, 30);
        aid4.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(aid4);


        id3 = new JLabel("Address:");
        id3.setBounds(50, 220, 100, 30);
        id3.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(id3);

        aid3 = new JLabel(Address);
        aid3.setBounds(200, 220, 300, 30);
        aid3.setFont(new Font("serif", Font.BOLD, 20));
        id9.add(aid3);

        b1 = new JButton("Display");
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setBounds(100, 520, 100, 30);
        b1.addActionListener(this);
        id9.add(b1);

        b2 = new JButton("cancel");
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.WHITE);
        b2.setBounds(250, 520, 100, 30);
        b2.addActionListener(this);
        id9.add(b2);

    }
    public void actionPerformed(ActionEvent ae){

        if(ae.getSource()==b1){
            JOptionPane.showMessageDialog(null,"Displayed successfully");
            f.setVisible(false);
            new Details();
        }
        if(ae.getSource()==b2){
            f.setVisible(false);
            new ViewStudent();
        }
    }
    public static void main(String[] args){
        new DisplayData("Display Data");
    }
}
