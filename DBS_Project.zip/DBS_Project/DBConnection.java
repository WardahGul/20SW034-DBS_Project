package DBS_Project;
import java.sql.*;
public class DBConnection {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/studentms";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "";

    public Connection conn = null;
    public Statement stmt = null;

    public DBConnection(){

        try {
            //STEP 2: Register load JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
             stmt= conn.createStatement();
            //STEP 4: Execute a query
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
